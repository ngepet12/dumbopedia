package com.example.drag.iotmqtt;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import android.text.format.DateFormat;
import android.widget.Toast;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.Calendar;

public class pakan extends AppCompatActivity {

    private TimePickerDialog timePickerDialog;
    private TextView tvTimeResult,tvTimeResult2;
    private Button button,button2;

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pakan);

        tvTimeResult = (TextView) findViewById(R.id.textView2);
        tvTimeResult2 = (TextView) findViewById(R.id.textView3);

        button = (Button) findViewById(R.id.button);
        button2 = (Button) findViewById(R.id.button9);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    ShowTimeDialog();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rootNode = FirebaseDatabase.getInstance();
                reference = rootNode.getReference("value");

                reference.setValue("test");

            }
        });




}
    private void ShowTimeDialog(){
                Calendar calendar = Calendar.getInstance();

                timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        tvTimeResult.setText(+hourOfDay+"");
                        tvTimeResult2.setText(+minute+"");

                    }
                },
                        calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE), DateFormat.is24HourFormat(this));
                timePickerDialog.show();
    }

}
